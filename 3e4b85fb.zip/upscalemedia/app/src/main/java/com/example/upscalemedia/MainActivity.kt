package com.example.upscalemedia

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    companion object {
        const val VIDEO_REQUEST = 1001
        const val IMAGE_REQUEST = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            UpscaleTheme {
                var mode by remember { mutableStateOf<Mode?>(null) }
                val ctx = LocalContext.current

                if (mode == null) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.title),
                                fontSize = 32.sp,
                                modifier = Modifier.padding(bottom = 10.dp)
                            )
                            Text(
                                text = stringResource(R.string.welcome),
                                modifier = Modifier.padding(bottom = 20.dp)
                            )

                            Button(
                                onClick = { mode = Mode.VIDEO },
                                modifier = Modifier.fillMaxWidth(0.8f).padding(10.dp)
                            ) {
                                Text(stringResource(R.string.upscale_video))
                            }

                            Button(
                                onClick = { mode = Mode.IMAGE },
                                modifier = Modifier.fillMaxWidth(0.8f).padding(10.dp)
                            ) {
                                Text(stringResource(R.string.upscale_image))
                            }
                        }
                    }
                } else {
                    ProcessingScreen(mode) {
                        mode = null
                    }
                }
            }
        }
    }

    @Composable
    private fun ProcessingScreen(mode: Mode, onBack: () -> Unit) {
        val ctx = LocalContext.current
        var fileUri by remember { mutableStateOf<String?>(null) }
        var isProcessing by remember { mutableStateOf(false) }
        var timeEst by remember { mutableStateOf(0) }

        val pickMedia = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                fileUri = uri.toString()
                // Ejemplo de cálculo de tiempo en segundos
                val size = 1024 * 1024 * 5 // 5 MB de ejemplo
                val factor = if (mode == Mode.VIDEO) 15 else 2
                timeEst = (size / 1024L / 1024L * factor).toInt()
                Toast.makeText(ctx, ctx.getString(R.string.processing), Toast.LENGTH_SHORT).show()
                isProcessing = true
                // En la app real aquí llamarías a FFmpeg o al procesador de imagen
            } else {
                Toast.makeText(ctx, ctx.getString(R.string.error_no_media), Toast.LENGTH_SHORT).show()
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(20.dp)
        ) {
            Text("$mode ${stringResource(R.string.upscale_video)}", fontSize = 24.sp)
            Spacer(Modifier.height(20.dp))

            Button(
                onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
                        || ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                    ) {
                        when (mode) {
                            Mode.VIDEO -> pickMedia.launch(arrayOf("video/*"))
                            Mode.IMAGE -> pickMedia.launch(arrayOf("image/*"))
                        }
                    } else {
                        Toast.makeText(ctx, "Permiso de media requerido", Toast.LENGTH_SHORT).show()
                    }
                }
            ) {
                Text(stringResource(R.string.select_file))
            }

            if (isProcessing) {
                Text(stringResource(R.string.processing), style = MaterialTheme.typography.titleMedium)
                Text(ctx.getString(R.string.estimated_time, timeEst))
            }

            if (!isProcessing && fileUri != null) {
                Text(stringResource(R.string.completed))
                Text(stringResource(R.string.save_to_gallery))
            }

            Button(
                onClick = { onBack() },
                modifier = Modifier.padding(top = 20.dp)
            ) {
                Text("← Volver")
            }
        }
    }

    enum class Mode {
        VIDEO, IMAGE
    }
}
