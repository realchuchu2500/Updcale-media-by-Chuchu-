package com.example.upscalemedia

// Ejemplo de cómo se llamaría FFmpeg desde Android
// NOTA: requiere que integres mobile-ffmpeg en el proyecto
// https://github.com/axet/android-ffmpeg

class FFmpegUtils {
    companion object {
        // Upscale a 4K con denoise y nitidez (ejemplo de comando)
        fun getUpscaleVideo4KCommand(inputPath: String, outputPath: String): Array<String> {
            return arrayOf(
                "-i", inputPath,
                "-vf", "scale=3840:2160:flags=lanczos,hqdn3d=4:3:6:6,unsharp=7:7:1.0:3:3:0.0",
                "-c:v", "libx264",
                "-crf", "18",
                "-preset", "medium",
                "-c:a", "aac",
                "-b:a", "192k",
                outputPath
            )
        }

        // Upscale + mejora de imagen (este ejemplo usa solo comandos de FFmpeg fotos)
        fun getUpscaleImage4KCommand(inputPath: String, outputPath: String): Array<String> {
            return arrayOf(
                "-i", inputPath,
                "-vf", "scale=3840:2160:flags=lanczos,unsharp=5:5:1.0:3:3:0.0",
                "-compression_level", "9",
                outputPath
            )
        }
    }
}
